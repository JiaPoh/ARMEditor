/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>BLX OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getBLX_OP()
 * @model
 * @generated
 */
public interface BLX_OP extends branch_instr
{
} // BLX_OP
