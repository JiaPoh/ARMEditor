/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>CMP OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getCMP_OP()
 * @model
 * @generated
 */
public interface CMP_OP extends compare_test_instr
{
} // CMP_OP
