/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>MVN OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getMVN_OP()
 * @model
 * @generated
 */
public interface MVN_OP extends mov_instr
{
} // MVN_OP
