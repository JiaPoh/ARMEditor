/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>BX OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getBX_OP()
 * @model
 * @generated
 */
public interface BX_OP extends branch_instr
{
} // BX_OP
