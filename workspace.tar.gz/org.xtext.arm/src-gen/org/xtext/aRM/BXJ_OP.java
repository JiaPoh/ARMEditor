/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>BXJ OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getBXJ_OP()
 * @model
 * @generated
 */
public interface BXJ_OP extends branch_instr
{
} // BXJ_OP
