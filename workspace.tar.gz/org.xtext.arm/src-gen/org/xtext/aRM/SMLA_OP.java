/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SMLA OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getSMLA_OP()
 * @model
 * @generated
 */
public interface SMLA_OP extends mul_4R_instr
{
} // SMLA_OP
