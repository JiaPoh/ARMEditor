/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>MLA OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getMLA_OP()
 * @model
 * @generated
 */
public interface MLA_OP extends mul_4R_instr
{
} // MLA_OP
