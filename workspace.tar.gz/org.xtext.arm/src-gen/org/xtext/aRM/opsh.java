/**
 */
package org.xtext.aRM;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>opsh</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getopsh()
 * @model
 * @generated
 */
public interface opsh extends EObject
{
} // opsh
