/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>UMLAL OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getUMLAL_OP()
 * @model
 * @generated
 */
public interface UMLAL_OP extends mul_4R_instr
{
} // UMLAL_OP
