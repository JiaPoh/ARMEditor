/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>adrl adr instr</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getadrl_adr_instr()
 * @model
 * @generated
 */
public interface adrl_adr_instr extends OperationInstr
{
} // adrl_adr_instr
