/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>BIC OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getBIC_OP()
 * @model
 * @generated
 */
public interface BIC_OP extends logical_instr
{
} // BIC_OP
