/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>ADD OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getADD_OP()
 * @model
 * @generated
 */
public interface ADD_OP extends add_sub_instr
{
} // ADD_OP
