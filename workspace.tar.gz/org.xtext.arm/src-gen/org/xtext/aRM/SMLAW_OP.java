/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SMLAW OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getSMLAW_OP()
 * @model
 * @generated
 */
public interface SMLAW_OP extends mul_4R_instr
{
} // SMLAW_OP
