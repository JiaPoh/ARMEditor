/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>ORR OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getORR_OP()
 * @model
 * @generated
 */
public interface ORR_OP extends logical_instr
{
} // ORR_OP
