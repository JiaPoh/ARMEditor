/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>ADC OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getADC_OP()
 * @model
 * @generated
 */
public interface ADC_OP extends add_sub_instr
{
} // ADC_OP
