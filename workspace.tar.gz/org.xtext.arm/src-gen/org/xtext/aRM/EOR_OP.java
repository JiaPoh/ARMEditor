/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>EOR OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getEOR_OP()
 * @model
 * @generated
 */
public interface EOR_OP extends logical_instr
{
} // EOR_OP
