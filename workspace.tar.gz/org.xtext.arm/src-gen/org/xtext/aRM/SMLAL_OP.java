/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SMLAL OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getSMLAL_OP()
 * @model
 * @generated
 */
public interface SMLAL_OP extends mul_4R_instr
{
} // SMLAL_OP
