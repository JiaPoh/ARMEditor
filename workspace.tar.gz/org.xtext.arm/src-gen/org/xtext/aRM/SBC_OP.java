/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SBC OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getSBC_OP()
 * @model
 * @generated
 */
public interface SBC_OP extends add_sub_instr
{
} // SBC_OP
