/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SWPB OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getSWPB_OP()
 * @model
 * @generated
 */
public interface SWPB_OP extends swp_instr
{
} // SWPB_OP
