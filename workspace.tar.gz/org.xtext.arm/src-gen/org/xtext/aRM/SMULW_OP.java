/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SMULW OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getSMULW_OP()
 * @model
 * @generated
 */
public interface SMULW_OP extends mul_3R_instr
{
} // SMULW_OP
