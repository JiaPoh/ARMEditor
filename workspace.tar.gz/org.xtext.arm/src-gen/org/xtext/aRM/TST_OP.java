/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>TST OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getTST_OP()
 * @model
 * @generated
 */
public interface TST_OP extends compare_test_instr
{
} // TST_OP
