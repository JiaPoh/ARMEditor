/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>CMN OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getCMN_OP()
 * @model
 * @generated
 */
public interface CMN_OP extends compare_test_instr
{
} // CMN_OP
