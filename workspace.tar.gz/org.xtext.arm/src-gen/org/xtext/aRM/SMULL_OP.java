/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SMULL OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getSMULL_OP()
 * @model
 * @generated
 */
public interface SMULL_OP extends mul_4R_instr
{
} // SMULL_OP
