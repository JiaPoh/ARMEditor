/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>svc instr</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getsvc_instr()
 * @model
 * @generated
 */
public interface svc_instr extends OperationInstr
{
} // svc_instr
