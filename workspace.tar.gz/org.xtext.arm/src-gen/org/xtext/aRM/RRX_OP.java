/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>RRX OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getRRX_OP()
 * @model
 * @generated
 */
public interface RRX_OP extends shift_instr
{
} // RRX_OP
