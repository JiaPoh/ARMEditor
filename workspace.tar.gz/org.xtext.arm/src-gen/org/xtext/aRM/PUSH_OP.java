/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>PUSH OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getPUSH_OP()
 * @model
 * @generated
 */
public interface PUSH_OP extends push_pop_instr
{
} // PUSH_OP
