/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>BL OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getBL_OP()
 * @model
 * @generated
 */
public interface BL_OP extends branch_instr
{
} // BL_OP
