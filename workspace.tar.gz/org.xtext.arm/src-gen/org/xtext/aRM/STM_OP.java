/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>STM OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getSTM_OP()
 * @model
 * @generated
 */
public interface STM_OP extends ldm_instr
{
} // STM_OP
