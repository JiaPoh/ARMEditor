/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>BOP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getB_OP()
 * @model
 * @generated
 */
public interface B_OP extends branch_instr
{
} // B_OP
