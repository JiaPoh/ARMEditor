/**
 */
package org.xtext.aRM;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Operand2</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getOperand2()
 * @model
 * @generated
 */
public interface Operand2 extends EObject
{
} // Operand2
