/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>POP OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getPOP_OP()
 * @model
 * @generated
 */
public interface POP_OP extends push_pop_instr
{
} // POP_OP
