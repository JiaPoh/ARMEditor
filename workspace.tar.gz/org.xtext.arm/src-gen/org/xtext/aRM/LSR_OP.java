/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>LSR OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getLSR_OP()
 * @model
 * @generated
 */
public interface LSR_OP extends shift_instr
{
} // LSR_OP
