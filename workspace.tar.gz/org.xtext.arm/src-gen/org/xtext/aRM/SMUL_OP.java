/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SMUL OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getSMUL_OP()
 * @model
 * @generated
 */
public interface SMUL_OP extends mul_3R_instr
{
} // SMUL_OP
