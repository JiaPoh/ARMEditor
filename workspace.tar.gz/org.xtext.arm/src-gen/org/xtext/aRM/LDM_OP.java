/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>LDM OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getLDM_OP()
 * @model
 * @generated
 */
public interface LDM_OP extends ldm_instr
{
} // LDM_OP
