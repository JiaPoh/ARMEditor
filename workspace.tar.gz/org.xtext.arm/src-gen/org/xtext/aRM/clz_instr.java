/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>clz instr</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getclz_instr()
 * @model
 * @generated
 */
public interface clz_instr extends OperationInstr
{
} // clz_instr
