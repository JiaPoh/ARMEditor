/**
 */
package org.xtext.aRM;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Instr</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getARMInstr()
 * @model
 * @generated
 */
public interface ARMInstr extends EObject
{
} // ARMInstr
