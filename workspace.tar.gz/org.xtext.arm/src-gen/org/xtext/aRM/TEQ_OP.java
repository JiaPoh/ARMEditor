/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>TEQ OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getTEQ_OP()
 * @model
 * @generated
 */
public interface TEQ_OP extends compare_test_instr
{
} // TEQ_OP
