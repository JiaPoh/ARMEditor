/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>AND OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getAND_OP()
 * @model
 * @generated
 */
public interface AND_OP extends logical_instr
{
} // AND_OP
