/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>LSL OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getLSL_OP()
 * @model
 * @generated
 */
public interface LSL_OP extends shift_instr
{
} // LSL_OP
