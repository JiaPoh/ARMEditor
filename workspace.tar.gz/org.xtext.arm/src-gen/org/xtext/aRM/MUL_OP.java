/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>MUL OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getMUL_OP()
 * @model
 * @generated
 */
public interface MUL_OP extends mul_3R_instr
{
} // MUL_OP
