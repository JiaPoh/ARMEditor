/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>msr instr</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getmsr_instr()
 * @model
 * @generated
 */
public interface msr_instr extends OperationInstr
{
} // msr_instr
