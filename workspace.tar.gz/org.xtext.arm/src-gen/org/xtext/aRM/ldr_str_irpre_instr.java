/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>ldr str irpre instr</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getldr_str_irpre_instr()
 * @model
 * @generated
 */
public interface ldr_str_irpre_instr extends OperationInstr
{
} // ldr_str_irpre_instr
