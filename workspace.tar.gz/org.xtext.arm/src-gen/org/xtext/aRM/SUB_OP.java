/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SUB OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getSUB_OP()
 * @model
 * @generated
 */
public interface SUB_OP extends add_sub_instr
{
} // SUB_OP
