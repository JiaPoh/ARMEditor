/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>RSB OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getRSB_OP()
 * @model
 * @generated
 */
public interface RSB_OP extends add_sub_instr
{
} // RSB_OP
