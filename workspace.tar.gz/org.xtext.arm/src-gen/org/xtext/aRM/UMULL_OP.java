/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>UMULL OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getUMULL_OP()
 * @model
 * @generated
 */
public interface UMULL_OP extends mul_4R_instr
{
} // UMULL_OP
