/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>MOV OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getMOV_OP()
 * @model
 * @generated
 */
public interface MOV_OP extends mov_instr
{
} // MOV_OP
