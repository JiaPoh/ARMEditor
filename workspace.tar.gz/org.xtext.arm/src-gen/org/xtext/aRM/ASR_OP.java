/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>ASR OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getASR_OP()
 * @model
 * @generated
 */
public interface ASR_OP extends shift_instr
{
} // ASR_OP
