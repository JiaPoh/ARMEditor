/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>RSC OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getRSC_OP()
 * @model
 * @generated
 */
public interface RSC_OP extends add_sub_instr
{
} // RSC_OP
