/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>mrs instr</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getmrs_instr()
 * @model
 * @generated
 */
public interface mrs_instr extends OperationInstr
{
} // mrs_instr
