/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Operation Instr</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getOperationInstr()
 * @model
 * @generated
 */
public interface OperationInstr extends ARMInstr
{
} // OperationInstr
