/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>MLS OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getMLS_OP()
 * @model
 * @generated
 */
public interface MLS_OP extends mul_4R_instr
{
} // MLS_OP
