/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SWP OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getSWP_OP()
 * @model
 * @generated
 */
public interface SWP_OP extends swp_instr
{
} // SWP_OP
