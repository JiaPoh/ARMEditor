/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>ROR OP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getROR_OP()
 * @model
 * @generated
 */
public interface ROR_OP extends shift_instr
{
} // ROR_OP
