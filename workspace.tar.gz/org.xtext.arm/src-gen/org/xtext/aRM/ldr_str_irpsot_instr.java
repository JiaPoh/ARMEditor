/**
 */
package org.xtext.aRM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>ldr str irpsot instr</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.aRM.ARMPackage#getldr_str_irpsot_instr()
 * @model
 * @generated
 */
public interface ldr_str_irpsot_instr extends OperationInstr
{
} // ldr_str_irpsot_instr
