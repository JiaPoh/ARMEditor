/**
 */
package org.xtext.aRM.impl;

import org.eclipse.emf.ecore.EClass;

import org.xtext.aRM.ARMPackage;
import org.xtext.aRM.RRX_OP;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>RRX OP</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class RRX_OPImpl extends shift_instrImpl implements RRX_OP
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected RRX_OPImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ARMPackage.Literals.RRX_OP;
  }

} //RRX_OPImpl
