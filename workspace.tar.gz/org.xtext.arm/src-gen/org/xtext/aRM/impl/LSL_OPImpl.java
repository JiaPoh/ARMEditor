/**
 */
package org.xtext.aRM.impl;

import org.eclipse.emf.ecore.EClass;

import org.xtext.aRM.ARMPackage;
import org.xtext.aRM.LSL_OP;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>LSL OP</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class LSL_OPImpl extends shift_instrImpl implements LSL_OP
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected LSL_OPImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ARMPackage.Literals.LSL_OP;
  }

} //LSL_OPImpl
