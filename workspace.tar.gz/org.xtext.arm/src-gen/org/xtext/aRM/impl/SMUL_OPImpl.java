/**
 */
package org.xtext.aRM.impl;

import org.eclipse.emf.ecore.EClass;

import org.xtext.aRM.ARMPackage;
import org.xtext.aRM.SMUL_OP;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>SMUL OP</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SMUL_OPImpl extends mul_3R_instrImpl implements SMUL_OP
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected SMUL_OPImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ARMPackage.Literals.SMUL_OP;
  }

} //SMUL_OPImpl
