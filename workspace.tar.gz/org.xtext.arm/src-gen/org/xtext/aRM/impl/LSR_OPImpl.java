/**
 */
package org.xtext.aRM.impl;

import org.eclipse.emf.ecore.EClass;

import org.xtext.aRM.ARMPackage;
import org.xtext.aRM.LSR_OP;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>LSR OP</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class LSR_OPImpl extends shift_instrImpl implements LSR_OP
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected LSR_OPImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ARMPackage.Literals.LSR_OP;
  }

} //LSR_OPImpl
