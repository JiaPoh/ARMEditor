/**
 */
package org.xtext.aRM.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.xtext.aRM.ARMInstr;
import org.xtext.aRM.ARMPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Instr</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ARMInstrImpl extends MinimalEObjectImpl.Container implements ARMInstr
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ARMInstrImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ARMPackage.Literals.ARM_INSTR;
  }

} //ARMInstrImpl
