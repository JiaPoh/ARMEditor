/**
 */
package org.xtext.aRM.impl;

import org.eclipse.emf.ecore.EClass;

import org.xtext.aRM.ARMPackage;
import org.xtext.aRM.SWPB_OP;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>SWPB OP</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SWPB_OPImpl extends swp_instrImpl implements SWPB_OP
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected SWPB_OPImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ARMPackage.Literals.SWPB_OP;
  }

} //SWPB_OPImpl
