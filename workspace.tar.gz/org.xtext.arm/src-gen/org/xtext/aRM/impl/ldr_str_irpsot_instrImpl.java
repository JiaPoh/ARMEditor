/**
 */
package org.xtext.aRM.impl;

import org.eclipse.emf.ecore.EClass;

import org.xtext.aRM.ARMPackage;
import org.xtext.aRM.ldr_str_irpsot_instr;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>ldr str irpsot instr</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ldr_str_irpsot_instrImpl extends OperationInstrImpl implements ldr_str_irpsot_instr
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ldr_str_irpsot_instrImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ARMPackage.Literals.LDR_STR_IRPSOT_INSTR;
  }

} //ldr_str_irpsot_instrImpl
