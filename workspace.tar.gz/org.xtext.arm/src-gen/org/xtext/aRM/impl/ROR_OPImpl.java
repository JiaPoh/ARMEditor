/**
 */
package org.xtext.aRM.impl;

import org.eclipse.emf.ecore.EClass;

import org.xtext.aRM.ARMPackage;
import org.xtext.aRM.ROR_OP;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>ROR OP</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ROR_OPImpl extends shift_instrImpl implements ROR_OP
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ROR_OPImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ARMPackage.Literals.ROR_OP;
  }

} //ROR_OPImpl
