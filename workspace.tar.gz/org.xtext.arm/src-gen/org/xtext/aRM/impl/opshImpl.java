/**
 */
package org.xtext.aRM.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.xtext.aRM.ARMPackage;
import org.xtext.aRM.opsh;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>opsh</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class opshImpl extends MinimalEObjectImpl.Container implements opsh
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected opshImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ARMPackage.Literals.OPSH;
  }

} //opshImpl
