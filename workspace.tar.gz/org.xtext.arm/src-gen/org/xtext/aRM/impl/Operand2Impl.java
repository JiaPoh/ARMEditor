/**
 */
package org.xtext.aRM.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.xtext.aRM.ARMPackage;
import org.xtext.aRM.Operand2;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Operand2</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class Operand2Impl extends MinimalEObjectImpl.Container implements Operand2
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected Operand2Impl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ARMPackage.Literals.OPERAND2;
  }

} //Operand2Impl
