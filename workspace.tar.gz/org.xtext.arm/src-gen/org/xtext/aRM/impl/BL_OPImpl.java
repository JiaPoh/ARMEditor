/**
 */
package org.xtext.aRM.impl;

import org.eclipse.emf.ecore.EClass;

import org.xtext.aRM.ARMPackage;
import org.xtext.aRM.BL_OP;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>BL OP</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class BL_OPImpl extends branch_instrImpl implements BL_OP
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected BL_OPImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ARMPackage.Literals.BL_OP;
  }

} //BL_OPImpl
