/**
 */
package org.xtext.aRM.impl;

import org.eclipse.emf.ecore.EClass;

import org.xtext.aRM.ARMPackage;
import org.xtext.aRM.MLS_OP;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>MLS OP</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class MLS_OPImpl extends mul_4R_instrImpl implements MLS_OP
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected MLS_OPImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ARMPackage.Literals.MLS_OP;
  }

} //MLS_OPImpl
