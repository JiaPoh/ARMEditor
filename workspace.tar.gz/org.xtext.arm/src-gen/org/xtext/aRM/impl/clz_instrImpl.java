/**
 */
package org.xtext.aRM.impl;

import org.eclipse.emf.ecore.EClass;

import org.xtext.aRM.ARMPackage;
import org.xtext.aRM.clz_instr;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>clz instr</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class clz_instrImpl extends OperationInstrImpl implements clz_instr
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected clz_instrImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ARMPackage.Literals.CLZ_INSTR;
  }

} //clz_instrImpl
