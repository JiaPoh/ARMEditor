/**
 */
package org.xtext.aRM.impl;

import org.eclipse.emf.ecore.EClass;

import org.xtext.aRM.ARMPackage;
import org.xtext.aRM.SWP_OP;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>SWP OP</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SWP_OPImpl extends swp_instrImpl implements SWP_OP
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected SWP_OPImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ARMPackage.Literals.SWP_OP;
  }

} //SWP_OPImpl
