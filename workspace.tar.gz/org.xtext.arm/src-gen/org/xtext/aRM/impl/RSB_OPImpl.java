/**
 */
package org.xtext.aRM.impl;

import org.eclipse.emf.ecore.EClass;

import org.xtext.aRM.ARMPackage;
import org.xtext.aRM.RSB_OP;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>RSB OP</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class RSB_OPImpl extends add_sub_instrImpl implements RSB_OP
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected RSB_OPImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ARMPackage.Literals.RSB_OP;
  }

} //RSB_OPImpl
