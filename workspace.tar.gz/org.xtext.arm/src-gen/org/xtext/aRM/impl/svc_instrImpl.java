/**
 */
package org.xtext.aRM.impl;

import org.eclipse.emf.ecore.EClass;

import org.xtext.aRM.ARMPackage;
import org.xtext.aRM.svc_instr;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>svc instr</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class svc_instrImpl extends OperationInstrImpl implements svc_instr
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected svc_instrImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ARMPackage.Literals.SVC_INSTR;
  }

} //svc_instrImpl
