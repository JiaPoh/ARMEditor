/**
 */
package org.xtext.aRM.impl;

import org.eclipse.emf.ecore.EClass;

import org.xtext.aRM.ADC_OP;
import org.xtext.aRM.ARMPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>ADC OP</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ADC_OPImpl extends add_sub_instrImpl implements ADC_OP
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ADC_OPImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ARMPackage.Literals.ADC_OP;
  }

} //ADC_OPImpl
