/**
 */
package org.xtext.aRM.impl;

import org.eclipse.emf.ecore.EClass;

import org.xtext.aRM.ARMPackage;
import org.xtext.aRM.BLX_OP;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>BLX OP</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class BLX_OPImpl extends branch_instrImpl implements BLX_OP
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected BLX_OPImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ARMPackage.Literals.BLX_OP;
  }

} //BLX_OPImpl
