/**
 */
package org.xtext.aRM.impl;

import org.eclipse.emf.ecore.EClass;

import org.xtext.aRM.ARMPackage;
import org.xtext.aRM.B_OP;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>BOP</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class B_OPImpl extends branch_instrImpl implements B_OP
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected B_OPImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ARMPackage.Literals.BOP;
  }

} //B_OPImpl
